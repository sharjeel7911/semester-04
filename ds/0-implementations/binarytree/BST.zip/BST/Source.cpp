#include "BST.h"

int main()
{
    BST bst;
    
    bst.insert(144);
    bst.insert(5);
    bst.insert(8);
    bst.insert(0);
    bst.insert(999);
    bst.insert(500);
    bst.insert(10);
    bst.insert(200);
    bst.insert(600);

    cout << "Delete Value: " << bst.deleteValue(500) << endl;

    cout << "Display: " << endl;
    bst.inorder();
    return 0;
}